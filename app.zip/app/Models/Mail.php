<?php
namespace App\Models;

class Mail
{
    public function sendMail(){
        $email = \Config\Services::email();
        $config = [
            'mailType' => 'html'
        ];
        $email->initialize($config);
        $email->setFrom('truc.machin@bazar.com', 'Machin Truc');
        $email->setTo('cariot.thomas@ynov.com');
        //$email->setCC('thomascariot@hotmail.com');
        $email->setSubject('Carte Cadeau');
        $email->setMessage('<h1 style="color: red">Bonjour</h1> ');
        $email->attach('https://www.orimi.com/pdf-test.pdf');

        //$file = new \CodeIgniter\Files\File();
        //echo $file->getRealPath();

        if (!$email->send()){
            return $email->printDebugger(['headers', 'subject', 'body']);
        } else {
            return true;
        }
    }
}