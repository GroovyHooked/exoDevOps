<?php

namespace App\Controllers;
use \App\Models\Mail;


class Home extends BaseController
{
    public function index()
    {
        $mail = new Mail();
        $isSent = $mail->sendMail();
        $data = [
            'debug' => $isSent
        ];

        if($isSent === true){
            echo 'success';
        } else {
            echo '<h3>error</h3>' . '<p>'. $data['debug'] . '</p>';
        }
    }
}
